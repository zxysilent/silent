package control

import "github.com/labstack/echo"

// func (w http.ResponseWriter,r *http.Request){

// }

func Index(ctx echo.Context) error {
	// return ctx.String(200, "string")
	return ctx.Redirect(302, "/login.html")
}
