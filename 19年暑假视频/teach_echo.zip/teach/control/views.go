package control

import "github.com/labstack/echo"

// LoginView
func LoginView(ctx echo.Context) error {
	return ctx.Render(200, "login.html", nil)
}

// AdmIndexView
func AdmIndexView(ctx echo.Context) error {
	return ctx.Render(200, "index.html", nil)
}
