package model

import (
	"errors"
	"log"
	"time"
)

type Article struct {
	Id        int64     `json:"id"`
	Cid       int64     `json:"cid"`               //class id
	ClassName string    `json:"class_name" db:"-"` // tag - 表示某种情况使用的时候 直接忽略
	Uid       int64     `json:"uid"`               //user id
	Title     string    `json:"title"`
	Origin    string    `json:"origin"`
	Author    string    `json:"author"`
	Content   string    `json:"content"`
	Hits      int64     `json:"hits"`
	Utime     time.Time `json:"utime"`
	Ctime     time.Time `json:"ctime"`
	Status    bool      `json:"status"`
}

// ArticleCount 数据总数
func ArticleCount() int {
	count := 0
	Db.Get(&count, "select count(*) from article")
	return count
}

// ArticlePage 分页数据
func ArticlePage(pi, ps int) ([]Article, error) {
	mods := make([]Article, 0, ps)
	err := Db.Select(&mods, "select * from article order by id desc limit ?,?", (pi-1)*ps, ps)
	cids := make([]int64, 0, ps)
	for i := 0; i < len(mods); i++ {
		// mods[i].ClassName = ClassNameById(mods[i].Cid)
		if !inOf(mods[i].Cid, cids) {
			cids = append(cids, mods[i].Cid)
		}
	}
	log.Println(cids)
	mp := ClassNameByIds(cids)
	for i := 0; i < len(mods); i++ {
		mods[i].ClassName = mp[mods[i].Cid]
		mods[i].Content = ""
	}
	return mods, err
}

func inOf(dst int64, arr []int64) bool {
	for i := 0; i < len(arr); i++ {
		if dst == arr[i] {
			return true
		}
	}
	return false
}

// 删除
func ArticleDrop(id int64) error {
	tx, _ := Db.Begin() //开启一个事务 保险
	result, err := tx.Exec("delete from article where id =?", id)
	if err != nil {
		// 回滚 ctrl+z
		tx.Rollback()
		return err
	}
	rows, _ := result.RowsAffected()
	if rows < 1 {
		//回滚 ctrl+z
		tx.Rollback()
		return errors.New("rows affected < 1")
	}
	// 提交 真正的写入磁盘
	tx.Commit()
	return nil
}

// ArticleAdd 添加新闻
func ArticleAdd(mod *Article) error {
	tx, _ := Db.Beginx() //开启事务
	result, err := tx.NamedExec("insert into article (title,author,cid,content,hits,ctime,utime,origin,status,uid) values (:title,:author,:cid,:content,:hits,:ctime,:utime,:origin,:status,:uid)", mod)
	if err != nil {
		tx.Rollback()
		return err
	}
	rows, _ := result.RowsAffected()
	if rows < 1 {
		tx.Rollback() //撤销
		return errors.New("rows affected < 1")
	}
	tx.Commit() //提交
	return nil
}
