package model

import (
	"errors"
	"time"

	"github.com/dgrijalva/jwt-go"
)

// User 表
type User struct {
	Id     int       `json:"id"`
	Num    string    `json:"num"`
	Name   string    `json:"name"`
	Pass   string    `json:"pass"`
	Phone  string    `json:"phone"`
	Email  string    `json:"email"`
	Status int       `json:"status"`
	Ctime  time.Time `json:"ctime"`
}

// UserGet 通过id 查询用户
func UserGet(id int64) (*User, error) {
	mod := &User{}
	err := Db.Get(mod, "select * from user where id = ? limit 1", id)
	return mod, err
}

// UserLogin 用户登录
func UserLogin(num string) (User, error) {
	mod := User{}
	err := Db.Get(&mod, "select * from user where num=? limit 1", num)
	return mod, err
}

// UserClaims token 携带的数据
type UserClaims struct {
	Id   int    `json:"id"`
	Num  string `json:"num"`
	Name string `json:"name"`
	jwt.StandardClaims
}

// 记不住 那就 那笔默写 16年 15 12 12：40
// UserPage 返回分页的数据
func UserPage(pi, ps int) ([]User, error) {
	mods := make([]User, 0, ps) //给定容器大小 但是现在不用
	err := Db.Select(&mods, "select * from user limit ?,?", (pi-1)*ps, ps)
	// rows, _ := Db.Query("")
	// mod := User{}
	// rows.Scan(&mod.Num, &mod.Name)
	// rows.Next()
	return mods, err
}

// UserCount 返回当前条件 数据总数 用来生成分页导航
func UserCount() int {
	count := 0
	Db.Get(&count, "select count(id) as count from user")
	return count
}

// UserDrop 删除 id
func UserDrop(id int64) error {
	tx, _ := Db.Begin() //开启事务
	result, err := tx.Exec("delete from user where id= ?", id)
	if err != nil {
		tx.Rollback()
		return err
	}
	rows, _ := result.RowsAffected()
	if rows < 1 {
		tx.Rollback() //撤销
		return errors.New("rows affected < 1")
	}
	tx.Commit() //提交
	return nil
}

// UserAdd 添加用户
func UserAdd(mod *User) error {
	tx, _ := Db.Begin() //开启事务
	result, err := tx.Exec("insert into user (num,`name`,pass,phone,email,ctime,status) values(?,?,?,?,?,?,?)", mod.Num, mod.Name, mod.Pass, mod.Phone, mod.Email, mod.Ctime, mod.Status)
	if err != nil {
		tx.Rollback()
		return err
	}
	rows, _ := result.RowsAffected()
	if rows < 1 {
		tx.Rollback() //撤销
		return errors.New("rows affected < 1")
	}
	tx.Commit() //提交
	return nil
}

// UserEdit 修改用户
func UserEdit(mod *User) error {
	tx, _ := Db.Beginx()
	// result, err := tx.Exec("update user set `name` =?,phone =?,email =? where id =?", mod.Name, mod.Phone, mod.Email, mod.Id)//字段少
	// xorm
	result, err := tx.NamedExec("update user set `name`=:name,phone=:phone,email=:email where id=:id", mod) //40
	// dropper
	if err != nil {
		tx.Rollback()
		return err
	}
	rows, _ := result.RowsAffected()
	if rows < 1 {
		tx.Rollback()
		return errors.New("rows affecter <1")
	}
	tx.Commit()
	return nil
}

func UserExists(num string) bool {
	mod := User{}
	err := Db.Get(&mod, "select * from user where num = ?", num)
	if err != nil {
		return false
	}
	return true
}
