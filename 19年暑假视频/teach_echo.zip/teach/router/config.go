package router

import (
	"io"
	"teach/model"
	"text/template"

	"github.com/dgrijalva/jwt-go"
	"github.com/labstack/echo"
	"github.com/zxysilent/utils"
)

type TemplateRenderer struct {
	templates *template.Template
}

func (t *TemplateRenderer) Render(w io.Writer, name string, data interface{}, c echo.Context) error {
	// // Add global methods if data is a map
	// if viewContext, isMap := data.(map[string]interface{}); isMap {
	// 	viewContext["reverse"] = c.Echo().Reverse
	// }

	if debug {
		t.templates = template.Must(template.ParseFiles("./views/login.html", "./views/index.html"))
	}

	return t.templates.ExecuteTemplate(w, name, data)
}

var renderer = &TemplateRenderer{
	templates: template.Must(template.ParseFiles("./views/login.html", "./views/index.html")),
}

// adm 下面过滤 中间件
func ServerHeader(next echo.HandlerFunc) echo.HandlerFunc {
	return func(ctx echo.Context) error {
		ctx.Response().Header().Set(echo.HeaderServer, "Echo/999")
		tokenString := ctx.FormValue("token")
		claims := model.UserClaims{}
		token, err := jwt.ParseWithClaims(tokenString, &claims, func(token *jwt.Token) (interface{}, error) {
			return []byte("123"), nil
		})
		if err == nil && token.Valid {
			//验证通过
			ctx.Set("uid", claims.Id) //Get
			return next(ctx)
		} else {
			//
			return ctx.JSON(utils.ErrJwt("jwt token 验证失败"))
		}
	}
}
