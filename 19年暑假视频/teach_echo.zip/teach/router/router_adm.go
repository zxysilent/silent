package router

import (
	"teach/control"

	"github.com/labstack/echo"
)

// AdmRouter 必须要token
func AdmRouter(adm *echo.Group) {
	adm.POST("/class/add", control.ClassAdd)
	adm.POST("/class/edit", control.ClassEdit)
	adm.GET("/class/drop/:id", control.ClassDrop) //path 参数

	adm.GET("/user/page", control.UserPage)
	adm.GET("/user/drop/:id", control.UserDrop)
	adm.POST("/user/add", control.UserAdd)
	adm.GET("/user/get/:id", control.UserGet)
	adm.POST("/user/edit", control.UserEdit)
	adm.GET("/article/drop/:id", control.ArticleDrop)

	adm.POST("/article/add", control.ArticleAdd)
}
