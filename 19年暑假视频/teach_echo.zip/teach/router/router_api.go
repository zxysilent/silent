package router

import (
	"teach/control"

	"github.com/labstack/echo"
)

func ApiRouter(api *echo.Group) {
	api.POST("/login", control.UserLogin) //只能是 post //浏览器直接访问是get
	api.GET("/class/all", control.ClassAll)
	api.GET("/class/page", control.ClassPage)
	api.GET("/class/get/:id", control.ClassGet) //:id path 参数
	api.GET("/article/page", control.ArticlePage)
}
